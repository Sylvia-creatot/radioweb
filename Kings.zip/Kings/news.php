<?php include_once 'partials/header.php'?>

<?php include_once 'partials/nav.php'?>
        <!-- start header content -->
        <div class="main-header1 serif bg-07 text-light d-flex align-items-center justify-content-center">
            <div class="inner-text text-center">
                <h1></h1>
               
            </div>

        </div>
        <!-- end header content -->
    </div>
    <!-- end headeer -->

      <!-- start news -->
      <div class="text-center serif font-weight-bold p-4 style1"><h2>BE UP-TO-DATE!!</h2></div>
    
      <div class="row m-5">
        <div class="col-lg-6  style2 d-flex justify-content-center align-items-center">
           <img src="images/main logo.jpg" class="shadow-7" alt="">
        </div>
        <div class="col-lg-6 ">
          <div class="text">
            <h2 class="serif pb-3 text-center ">
              SOOO...
            </h2>
            <P class="serif">WKU SDA KINGS FM </P>
            <P class="serif">
                              Headquartered in Kisumu, Kenya.
                               West Kenya Union Conference facilitates the work of the Seventh-day Adventist
                                Church in the western Kenya region covering up to fifteen counties
                                 of the Republic of Kenya.
                     </P>
               <P class="serif">We provide services and resources
                  for over 388000 thousand church members 
                  with 2,869 churches
                  and more than 100 companies throughout our territory.</P>
    
          </div>
          
        </div>
      </div>
       <!-- end news -->
       <?php include_once 'partials/footer.php'?>
 