<!-- start navigation -->
<nav class="navbar  navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand font-weight-bold serif pr-3" href="#"> <h2>kingsfm</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav mr-auto">
                  <li class="nav-item active">
                    <a class="nav-link font-weight-bold serif" href="index.php">Home <span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link font-weight-bold serif" href="about.php">About Us</a>
                    </li>
                  <li class="nav-item">
                    <a class="nav-link font-weight-bold serif" href="presenters.php">Our Presenters</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link font-weight-bold serif" href="schedule.php">Our Schedule</a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link font-weight-bold serif" href="shows.php">Shows</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link font-weight-bold serif" href="news.php">News</a>
                    </li>
                  <li class="nav-item">
                      <a class="nav-link font-weight-bold serif" href="contact.php">Contact Us</a>
                    </li>


                    <li class="nav-item">
                      <a class="nav-link font-weight-bold serif" href="#"> | kingsfm@gmail.com | +254 722 222 222</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link font-weight-bold serif" href="contact.php">
                        <img src="images/main logo.jpg" alt="radio" style="width:70px;" title="Go to dashboard">
                      </a>
                    </li>
                </ul>
                <span class="navbar-text font-weight-bold serif">
                <ul class="navbar-nav mr-auto">
                  
                   <li class="nav-item">
                      <a class="nav-link font-weight-bold serif active" href="login.php">|  | </a>    
                    </li>
                    <li class="nav-item">
                      <a class="nav-link font-weight-bold serif active" href="register.php">| |</a>    
                    </li>
                </ul>
                </span>
            </div>
        </nav>
        <!-- end navigation -->