   
     <!-- start footer section -->
     <div class="footer text-light " style="background: url(images/ONAIR.jpg); 
     background-repeat:no-repeat;background-size: 100%;">
      <div class="cont1 bg-07 p-5">
        <div class="row">
          <div class="col-lg-4 font-weight-bold">
            <p class="serif">| WKU SDA KINGS FM |</p>
            <p class="serif">| Headquartered in Kisumu, Kenya.
               West Kenya Union Conference facilitates the work of the
                Seventh-day Adventist Church in the western Kenya region
                 covering up to fifteen counties of the Republic of Kenya. |</p>
                 <p class="serif"> | We provide services and resources for over
                    388000 thousand church members with 2,869 churches 
                    and more than 100 companies throughout our territory. |</p>
          </div>
          <div class="col-lg-4 font-weight-bold">
            <p class="serif">| kingsfm@gmail.com |</p>
            <p class="serif">| +254 722 222 222 |</p>
          </div>
          <div class="col-lg-4 font-weight-bold">
          <div class="footer text-light " style="background: url(images/LOGO.png);
           background-repeat:no-repeat;background-size: 70%;">
          </div>
        </div>
      </div>
    </div>
    <!-- end footer section -->
    
    <!-- javascript lnking -->
    <script src="js/script.js"></script>
</body>
</html>