 <!-- start header -->
 <div class="header1" id="header" style="background: url('images/main logo.jpg'); 
 background-repeat:no-repeat;background-size: 60%;">
 
     