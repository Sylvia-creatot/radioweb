<?php include_once 'partials/header.php'?>

<?php include_once 'partials/header2.php'?>
<?php include_once 'partials/nav.php'?>
        <!-- start header content -->
        <div class="main-header1 serif bg-07 text-light d-flex align-items-center justify-content-center">
            <div class="inner-text text-center">
                <h1>CONTACT US</h1>
            </div>

        </div>
        <!-- end header content -->
    </div>
    <!-- end headeer -->

     <!-- start contact -->
     
     <div class="text-center serif font-weight-bold p-4 style1"><h2> WRITE TO US.</h2></div>

     <div class="cont2 p-5">
      
        <form class="px-4 py-3">
          <div class="form-group">
            <label for="exampleDropdownFormEmail1">Enter Name...</label>
            <input type="text" class="form-control" id="exampleDropdownFormEmail1" placeholder="your name">
          </div>
          <div class="form-group">
            <label for="exampleDropdownFormEmail1">Enter Your Email Address...</label>
            <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com">
          </div>
          <div class="form-group">
            <label for="exampleDropdownFormPassword1">Write here...</label>
           <textarea class="form-control" name="" id="" cols="30" rows="10">Example: When do you have interviews?</textarea>
          </div>
          
          <button type="submit" class="btn btn-primary form-control" onclick="success()">Send </button>
        </form>
        
     </div>
    <!-- end contact -->
    <?php include_once 'partials/footer.php'?>
