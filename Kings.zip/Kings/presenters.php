<?php include_once 'partials/header.php'?>

<?php include_once 'partials/header2.php'?>
<?php include_once 'partials/nav.php'?>
        <!-- start header content -->
        <div class="main-header1 serif bg-07 text-light d-flex align-items-center justify-content-center">
            <div class="inner-text text-center">
                <h1>OUR PRESENTERS</h1>
               
            </div>

        </div>
        <!-- end header content -->
    </div>
    <!-- end headeer -->

     <!-- start presenters -->
     <div class="text-center serif font-weight-bold p-4 style1"><h2></h2></div>
    <div class="row p-4">
      <div class="col-lg-3">
        <img src="images/image rdio.jpg" onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src="images/kings fm.jpg"onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src="images/kings footer.jpg"onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src=""onclick="msg()" alt="">
      </div>
    </div>
    <div class="row p-4">
      <div class="col-lg-3">
        <img src=""onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src=""onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src=""onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src=""onclick="msg()" alt="">
      </div>
    </div>
     <div class="row p-4">
      <div class="col-lg-3">
        <img src="images/reall6.jpg"onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src="images/reall7.jpg"onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src="imges/reall8.jpg"onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src="images/reall9"onclick="msg()" alt="">
      </div>
      <div class="col-lg-3">
        <img src="images/reall10"onclick="msg()" alt="">
      </div>
    </div>
    <!-- end presenters -->
    <?php include_once 'partials/footer.php'?>
    
