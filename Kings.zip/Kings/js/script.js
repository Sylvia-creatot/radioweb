function msg(){
    
    alert ("TO ORDER, FIND US AT:\n \n | kingsfm@gmail.com |\n| kings@gmail.com |\n| +254 722 222 222 |")
}
function success(){
    alert ("message sent!!");
    
}