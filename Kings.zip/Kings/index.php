<?php include_once 'partials/header.php'?>
    <!-- start header -->
    <div class="header" id="header" style="background: url('images/main logo.jpg');
     background-repeat:no-repeat;background-size: 100%;">
 
<?php include_once 'partials/nav.php'?>
        <!-- start header content -->
        <div class="main-header serif bg-07 text-light d-flex align-items-center justify-content-center">
            <div class="inner-text text-center">
                <h1>GROWTH & NOURISHMENT</h1>
                <p>Tune in.
                </p>
                     <button class="btn btn-success; 
                     background-color: #008CBA; /* Green */
                     border: none;
                     color: white;">KINGS FM.</button>
            </div>

        </div>
        <!-- end header content -->
    </div>
    <!-- end headeer -->

     <!-- start home -->
     <div class="text-center serif font-weight-bold p-4 style1"><h2> WKUC RADIO STATION</h2></div>
    
    <div class="row m-5">
      
      <div class="col-lg-6 ">
        <div class="text">
          <h2 class="serif pb-3 text-center ">
            IS AN...
          </h2>
          <P class="serif">Adventist Station based in Kisumu, WKUC, 
            with a mission to bring hope to the hopeless and uplift 
            the weary through the songs, sermons, and programs. 
            Kings FM is run on Christian principles as avenue for an outreach, nourishment and holistic ministry
             for varied audiences with the Gospel message of Jesus[…]</P>
             <P class="serif"></P>
  
        </div>
        
      </div>
    </div>
     <!-- end home -->
     <?php include_once 'partials/footer.php'?>